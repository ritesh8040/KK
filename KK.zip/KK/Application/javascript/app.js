(function(angular) {
  'use strict';
var app = angular.module('myApp', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'ngPrint']);
app.controller('MyCtrl', function($scope) {
	$scope.date = new Date();
$scope.datas=[
             ];
		$scope.SNo="";
		$scope.Name="";
		$scope.Qty="";
		$scope.Amt="";
		$scope.kname="";
$scope.add = function(SNo,Name,Qty,Amt) {
        $scope.SNo=SNo;
		$scope.Name=Name;
		$scope.Qty=Qty;
		$scope.Amt=Amt;
		$scope.datas.push({'SNo': $scope.SNo, 'Name': $scope.Name, 'Qty': $scope.Qty, 'Amt':$scope.Amt});
		
		$scope.SNo="";
		$scope.Name="";
		$scope.Qty="";
		$scope.Amt="";
    };
	
	$scope.print=function(){
	var divToPrint=angular.element(document.querySelector('#printTable'));
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
	};
	$scope.save=function(){
	var SaveDate={'SlpNo':"auto", 'Date':$scope.date, 'Company':$scope.kname, 'data':$scope.datas};
	SaveDate=angular.toJson(SaveDate);
	alert(SaveDate);
	console.log(SaveDate);
	};
  /*$scope.gridOptions = {  };
   $scope.msg = {};
  $scope.gridOptions.columnDefs = [
    { name: 'SNo', enableCellEdit: true, displayName: 'SNo'},
	{ name: 'Name', enableCellEdit: true, displayName: 'Name'},
	{ name: 'Qty', enableCellEdit: true, displayName: 'Qty'},
	{ name: 'Amt', enableCellEdit: true, displayName: 'Amt'}
  ]; 	
  
  $scope.gridOptions.onRegisterApi = function(gridApi){
          $scope.gridApi = gridApi;
          gridApi.edit.on.afterCellEdit($scope,function(rowEntity, colDef, newValue, oldValue){
            $scope.msg.lastCellEdited = 'edited row id:' + rowEntity.SNo + ' Column:' + colDef.name + ' newValue:' + newValue + ' oldValue:' + oldValue ;
            $scope.$apply();
          });
        };
  $scope.gridOptions.data = [{SNo: "1", Name: "test 1", Qty: "1" , Amt:"1"},
                             {SNo: "2", Name: "test 2", Qty: "1" , Amt:"4"}
                            ];
							
*/
});
})(window.angular);